package in.co.job.portal.exception;



public class DuplicateRecordException  extends Exception
{
	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
